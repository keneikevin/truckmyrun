package com.example.truckmyrun.other

enum class SortType {
    DATE,
    RUNNING_TIME,
    AVG_SPEED,
    DISTANCE,
    CALORIES_BURNED
}
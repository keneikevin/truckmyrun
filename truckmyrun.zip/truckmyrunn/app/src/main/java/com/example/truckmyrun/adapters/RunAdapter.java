package com.example.truckmyrun.adapters;

class RunAdapter :RecyclerView.Adapter<RunAdapter.RunViewHolder>()
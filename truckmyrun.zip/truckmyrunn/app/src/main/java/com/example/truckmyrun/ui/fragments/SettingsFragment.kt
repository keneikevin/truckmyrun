package com.example.truckmyrun.ui.fragments

import androidx.fragment.app.Fragment
import com.example.truckmyrun.R


class SettingsFragment:Fragment(R.layout.fragment_settings) {
}